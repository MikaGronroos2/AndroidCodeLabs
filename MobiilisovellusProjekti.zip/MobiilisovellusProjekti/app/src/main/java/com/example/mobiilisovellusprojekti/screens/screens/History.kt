package com.example.mobiilisovellusprojekti.screens.screens

import androidx.compose.runtime.Composable
import androidx.navigation.NavController
import androidx.compose.ui.Modifier

@Composable
fun History(navController: NavController, modifier: Modifier, isDarkTheme: Boolean) {

}