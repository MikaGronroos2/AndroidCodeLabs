package com.example.mobiilisovellusprojekti.data

val defaultWords = listOf(

        Word(word = "apple", difficulty = 1),
    Word(word = "dog", difficulty = 1),
    Word(word = "car", difficulty = 1),
    Word(word = "house", difficulty = 1),
    Word(word = "ball", difficulty = 1),
    Word(word = "book", difficulty = 1),
    Word(word = "tree", difficulty = 1),
    Word(word = "fish", difficulty = 1),
    Word(word = "hat", difficulty = 1),
    Word(word = "shoe", difficulty = 1),

    Word(word = "guitarist", difficulty = 2),
    Word(word = "hunting", difficulty = 2),
    Word(word = "computer", difficulty = 2),
    Word(word = "bicycle", difficulty = 2),
    Word(word = "backpack", difficulty = 2),
    Word(word = "window", difficulty = 2),
    Word(word = "cooking", difficulty = 2),
    Word(word = "camera", difficulty = 2),
    Word(word = "airplane", difficulty = 2),
    Word(word = "lighthouse", difficulty = 2),

    Word(word = "freedom", difficulty = 3),
    Word(word = "philosophy", difficulty = 3),
    Word(word = "rocket", difficulty = 3),
    Word(word = "zoologist", difficulty = 3),
    Word(word = "quantum", difficulty = 3),
    Word(word = "democracy", difficulty = 3),
    Word(word = "revolution", difficulty = 3),
    Word(word = "illusion", difficulty = 3),
    Word(word = "hypnosis", difficulty = 3),
    Word(word = "microscope", difficulty = 3)
    )

