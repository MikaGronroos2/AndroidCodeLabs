package com.example.mobiilisovellusprojekti.screens.screens

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavController

@Composable
fun Player(navController: NavController, modifier: Modifier, isDarkTheme: Boolean) {

}